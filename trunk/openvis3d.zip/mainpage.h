/** \mainpage OpenVis3D library
*  \anchor openvis3dmain
*  <br> <B> Click on the Classes tab above </B> to see class descriptions.
*
*/